function add1(){
    document.querySelector('#post1').innerText++;
}

function add2(){
    document.querySelector('#post2').innerText++;
}

function add3(){
    document.querySelector('#post3').innerText++;
}