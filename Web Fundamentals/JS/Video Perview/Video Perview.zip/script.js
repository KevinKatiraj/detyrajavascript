console.log("page loaded...");

function over(element){
    console.log(element.src);
    element.play();
}
function out(element){
    element.pause();
}

